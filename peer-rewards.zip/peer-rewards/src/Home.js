import React, { useState, useEffect } from 'react';
import RewardsDetails from './RewardsDetails';
import RewardsProfile from './RewardsProfile';
import { MOCK_PROFILE_DATA } from './data/MockProfileData';
import '@rmwc/icon/styles';
import '@rmwc/grid/styles';

const Home = () => {
    const [profileData, setProfileData] = useState(null);

    useEffect(() => {
        setProfileData({...MOCK_PROFILE_DATA})
    }, []);

    return (
        profileData && <>
            <RewardsProfile profileData={profileData} />
            <RewardsDetails userId={profileData.userId} userName={profileData.name} />
        </>
    )
};

export default Home;