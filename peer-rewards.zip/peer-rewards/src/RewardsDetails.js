import React, { useEffect, useState } from "react";
import { IconButton, Icon, TabBar, Tab } from "rmwc";
import { MOCK_REWARDS } from "./data/MockProfileData";
import AddNewRewardDialog from './AddNewReward';
import "@rmwc/tabs/styles";



const RewardsDetails = ({ userId, userName }) => {
  const [activeTab, setActiveTab] = useState(0);
  const [rewards, setRewards] = useState([]);
  const [currentRewards, setCurrentRewards] = useState([]);
  const [showRewardDialog, setShowRewardDialog] = useState(false);

  useEffect(() => {
    setRewards([...MOCK_REWARDS]);
  }, []);

  useEffect(() => {
    const filterRewards = () => {
      setCurrentRewards(() =>
        rewards.filter(
          (reward) =>
            reward.rewardedById === userId || reward.rewardedToId === userId
        )
      );
    }
    activeTab && filterRewards();
  }, [activeTab, userId, rewards]);

  const addRewardData = (data) => {
    setActiveTab(0);
    const newData = {
      rewardedBy: userName,
      rewardedTo: data.to,
      date: format(new Date()),
      id: Math.random(),
      message: data.why,
      rewardedById: userId,
      rewardedToId: Math.random(),
      amount: data.reward
    }
    setRewards(prevData => ([...prevData, newData]));
    handleHideRewardClick();
  };

  const handleTabChange = (evt) => {
    setActiveTab(evt.detail.index);
  };

  const handleAddRewardClick = (e) => {
    e.preventDefault();
    setShowRewardDialog(true);
  }

  const handleHideRewardClick = () => {
    setShowRewardDialog(false);
  }

  return (
    <div>
      <TabBar
        activeTabIndex={activeTab}
        onActivate={handleTabChange}
        className="reward-tabs"
      >
        <Tab>Feed</Tab>
        <Tab>My Rewards</Tab>
      </TabBar>
      <div className="Add-reward-icon-container">
        <IconButton className="Add-reward-icon" icon="add" onClick={handleAddRewardClick} />
      </div>
      {rewards && (
        <div className="Feed-container">
          {(activeTab ? currentRewards : rewards).map((obj) => (
            <div key={obj.id} className="Reward-container">
              <div className="Reward-item-icon">
                <Icon icon="perm_identity" />
              </div>
              <div className="Reward-item-text">
                <p>{`${obj.rewardedTo} is rewarded by ${obj.rewardedBy}`}</p>
                <small>{obj.date}</small>
                <p>{obj.message}</p>
              </div>
            </div>
          ))}
        </div>
      )}
      {showRewardDialog ? <AddNewRewardDialog showRewardDialog={showRewardDialog} handleHideRewardClick={handleHideRewardClick} addRewardData={addRewardData} /> : null}
      {/* <AddNewRewardDialog showRewardDialog={showRewardDialog} /> */}
    </div>
  );
};

function format(inputDate) {
  let date, month, year;

  date = inputDate.getDate();
  month = inputDate.getMonth() + 1;
  year = inputDate.getFullYear();

    date = date
        .toString()
        .padStart(2, '0');

    month = month
        .toString()
        .padStart(2, '0');

  return `${date}/${month}/${year}`;
}


export default RewardsDetails;
