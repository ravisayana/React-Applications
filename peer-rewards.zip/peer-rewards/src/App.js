import Home from './Home';
import './App.css';
import '@rmwc/dialog/styles';

function App() {
  return (
    <div className="App">
      <header className="App-header">
        <p>Rewards</p>
      </header>
      <div className='App-body'>
        <Home />
      </div>
    </div>
  );
}

export default App;
