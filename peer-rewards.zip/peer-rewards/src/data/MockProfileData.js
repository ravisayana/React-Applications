export const MOCK_PROFILE_DATA = {
    name: 'Jane doe',
    totalRewardsGiven: 100,
    totalRewardsProvided: 250,
    userId: 101
}

export const MOCK_REWARDS = [
    {
        rewardedBy: 'Sender 1',
        rewardedTo: 'Reciever 1',
        date: '01-01-2023',
        id: 1,
        message: 'Reward message 1',
        rewardedById: 100,
        rewardedToId: 200,
        amount: 100
    },
    {
        rewardedBy: 'Jane doe',
        rewardedTo: 'Reciever 2',
        date: '01-01-2023',
        id: 2,
        message: 'Reward message 2',
        rewardedById: 101,
        rewardedToId: 201,
        amount: 100
    },
    {
        rewardedBy: 'Sender 3',
        rewardedTo: 'Reciever 3',
        date: '01-01-2023',
        id: 3,
        message: 'Reward message 3',
        rewardedById: 102,
        rewardedToId: 202,
        amount: 100
    }

]