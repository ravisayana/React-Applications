import React from 'react';
import { Grid, GridCell, GridRow, Icon } from 'rmwc';

const RewardsProfile = ({profileData}) => {
    return (
        profileData && <div className='Rewards-profile'>
            
            <Grid>
                <GridRow>
                    <GridCell span={3}><div className='Profile-icon'>
                        <Icon icon="perm_identity" />
                    </div></GridCell>
                    <GridCell span={4}>My Rewards</GridCell>
                    <GridCell span={5}>Give</GridCell>
                </GridRow>
                <GridRow>
                    <GridCell span={3}>{profileData.name}</GridCell>
                    <GridCell span={4}>{`$${profileData.totalRewardsProvided}`}</GridCell>
                    <GridCell span={5}>{`$${profileData.totalRewardsGiven}`}</GridCell>
                </GridRow>
            
            </Grid>
            
        </div>
    )
};

export default RewardsProfile;