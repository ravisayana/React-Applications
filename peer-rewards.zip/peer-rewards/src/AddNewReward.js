import React, { useState } from 'react';
import { Dialog, DialogActions, DialogButton, DialogContent, DialogTitle, TextField, Typography } from "rmwc";

const AddNewRewardDialog = ({ showRewardDialog, handleHideRewardClick, addRewardData }) => {
  const [data, setData] = useState({ to: '', reward: '', why: '' });
  const handleInputChange = ({ target }) => {
    setData(prevData => ({ ...prevData, [target.name]: target.value }));
  };

  return (
    <Dialog
      open={showRewardDialog}
      onClose={() => handleHideRewardClick()}
    >
      <DialogTitle>New Reward Modal</DialogTitle>
      <DialogContent>
        <div className='reward-modal-contianer'>
          <div className='reward-modal-input'>
            <Typography className='input-label' use="headline6">To</Typography>
            <TextField value={data.to} name="to" onChange={handleInputChange} />
          </div>
          <div className='reward-modal-input'>
            <Typography className='input-label' use="headline6">Reward</Typography>
            <TextField value={data.reward} name="reward" onChange={handleInputChange} />
          </div>
          <div className='reward-modal-input'>
            <Typography className='input-label' use="headline6">Why?</Typography>
            <TextField value={data.why} name="why" onChange={handleInputChange} />
          </div>
        </div>
      </DialogContent>
      <DialogActions>
        <DialogButton raised isDefaultAction onClick={() => addRewardData(data)}>
          Reward
        </DialogButton>
      </DialogActions>
    </Dialog>
  )
}

export default AddNewRewardDialog;
